from telegram import Bot, error as telegram_error
import asyncio
import time

async def send_to_telegram(message: str, image_path: str):
    bot = Bot(token='Your_Telegram_Bot_Token')
    try:
        with open(image_path, 'rb') as photo:
            await bot.send_photo(chat_id='Your_Chat_ID', photo=photo, caption=message)
        print("Analysis sent to Telegram successfully.")
    except telegram_error.RetryAfter as e:
        print(f"Flood control exceeded. Retrying in {e.retry_after} seconds...")
        time.sleep(e.retry_after)  # Wait the required time before retrying
        await send_to_telegram(message, image_path)  # Recursively call the function to retry
    except telegram_error.TelegramError as e:
        print(f"Error sending message to Telegram: {e}")
    finally:
        await bot.close()

# Example usage
asyncio.run(send_to_telegram("Here's your analysis!", "/path/to/your/image.png"))
