import openai
from PIL import Image
from telegram import Bot
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import GeckoDriverManager
import time
import io
import base64
import os

# Set up Telegram Bot
bot_token = "5675379828:AAHjRijYM1mF1WaIK2egcMg4vXp4yn9pYyY"
chat_id = "-1001819154166"
bot = Bot(token=bot_token)

# Configure OpenAI
openai.api_key = "sk-proj-GUUtilq9bqZ8gNAnRP3bT3BlbkFJBYVTDb9T2sxJg8a12zI0"

# Selenium WebDriver Setup for Firefox
options = webdriver.FirefoxOptions()
options.headless = True

# Install GeckoDriver
gecko_driver_path = GeckoDriverManager().install()

# Create WebDriver with the installed GeckoDriver
driver = webdriver.Firefox(service=Service(gecko_driver_path), options=options)

# Function to take TradingView chart screenshot
def capture_tradingview_chart(url: str, file_path: str):
    try:
        driver.get(url)
        time.sleep(20)  # Allow chart to load
        screenshot = driver.get_screenshot_as_png()
        image = Image.open(io.BytesIO(screenshot))
        # cropped_image = image.crop((50, 100, 1200, 700))  # Adjust cropping as needed
        image.save(file_path)
        print(f"Chart screenshot saved to {file_path}")
    except Exception as e:
        print(f"Error capturing TradingView chart: {e}")

# Analyze chart using GPT-4 (text-based analysis)
def analyze_chart(image_path: str) -> str:
    try:
        with open(image_path, "rb") as image_file:
            image_base64 = base64.b64encode(image_file.read()).decode('utf-8')

        prompt = f"Analyze the following chart and predict the trend, entry points, exit points, and stop loss based on the trend:\n\n![Chart](data:image/png;base64,{image_base64})"
        response = openai.Completion.create(
            model="gpt-4",  # or "gpt-4-turbo"
            prompt=prompt,
            max_tokens=300,
            n=1,
            stop=None,
            temperature=0.7
        )
        analysis = response.choices[0].text.strip()
        return analysis
    except Exception as e:
        print(f"Error analyzing chart: {e}")
        return "Could not analyze the chart due to an error."

# Send analysis results via Telegram
def send_to_telegram(message: str, image_path: str):
    try:
        with open(image_path, "rb") as photo:
            bot.send_photo(chat_id=chat_id, photo=photo, caption=message)
        print("Analysis sent to Telegram successfully.")
    except Exception as e:
        print(f"Error sending message to Telegram: {e}")

# Example Usage
tradingview_chart_url = "https://www.tradingview.com/chart/BBkarDYY/"
screenshot_path = "tradingview_chart.png"

# Step 1: Capture TradingView chart
capture_tradingview_chart(tradingview_chart_url, screenshot_path)

# Step 2: Analyze the chart with GPT-4
# chart_analysis = analyze_chart(screenshot_path)
chart_analysis = "Test"
# Step 3: Send analysis to Telegram
send_to_telegram(chart_analysis, screenshot_path)

# Cleanup
driver.quit()